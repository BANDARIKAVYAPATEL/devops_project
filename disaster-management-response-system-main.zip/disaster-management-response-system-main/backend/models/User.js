const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({

  name: String,

  email: {
    type: String,
    unique: true
  },

  phone: String,

  location: String,

  username: String,

  password: String,

  role: {
    type: String,
    default: "user"
  }

});

module.exports =
  mongoose.model(
    "User",
    userSchema
  );